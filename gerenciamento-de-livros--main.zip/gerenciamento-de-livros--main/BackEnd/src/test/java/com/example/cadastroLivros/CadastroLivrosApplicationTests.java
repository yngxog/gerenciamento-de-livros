package com.example.cadastroLivros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastroLivrosApplicationTests {

	@Test
	void contextLoads() {
	}

}
